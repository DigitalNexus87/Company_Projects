import { useState } from 'react'
import HeroSection from './component/herosection'
import SearchForm from './component/searchform'
import Services from './component/Services'
import NewestCars from './component/newcar'
import CarList from './component/CarList'
import CarList1 from './component/carlist1'
import ClientTestimonials from './component/ClientTestimonials'
import Footer from './component/footer'
import LogoGallery from './component/logograllary'



function App() {

  return (
    <>
      <div>
      <HeroSection />
      <SearchForm/>
      <Services/>
      <NewestCars/>
      <CarList/>
      <CarList1/>
      <ClientTestimonials/>
      <LogoGallery/>
      <Footer/>

    </div>
    </>
  )
}

export default App
