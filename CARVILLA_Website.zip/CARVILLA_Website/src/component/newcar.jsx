import React from 'react';
import './NewestCars.css'; 

const NewestCars = () => {
    return (
        <div className='ne'>
        <span className="cars112">Checkout the Latest Cars</span><br></br>
        <h1 className="cars12">Newest Cars</h1>
        <div className="job-help-section">
        
            <div className="image-grid">
                <img src="car2.png" alt="Team" className="image" />
            </div>
           
              
          
            <div className="text-content">
                <h2 className="heading">Chevrolet Camaro ZA100</h2>
                <p className="description">
                    We are dedicated to helping you secure the best job opportunities and connect with skilled talent. 
                    Our platform is designed to match candidates with roles that suit their expertise and employers 
                    with candidates who can help drive success. <br></br>
                    Whether you're seeking a new career path or looking 
                    for talent to join your team, we're here to support you.
                </p>

              
                <button className="read-more-button">Read More</button>
            </div>
        </div>
        </div>
    );
};

export default NewestCars;
