import React from 'react';

const LogoGallery = () => {
  const logos = [
    'logo7.png',
    'logo1.png',
    'logo2.png',
    'logo3.png',
    'logo4.png',
    'logo5.png',
  ];

  return (
    <div style={styles.gallery}>
      {logos.map((logo, index) => (
        <img key={index} src={logo} alt="Company Logo" style={styles.logo} />
      ))}
    </div>
  );
};

const styles = {
  gallery: {
    display: 'flex',
    justifyContent: 'space-around',
   // gap: '70px',
  
    flexWrap: 'wrap',
    padding: '20px',
  },
  logo: {
    maxWidth: '100px',
    maxHeight: '50px',
    objectFit: 'contain',
  }
};

export default LogoGallery;
