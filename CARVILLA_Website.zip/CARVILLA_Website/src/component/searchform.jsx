import React from 'react';
import "./searchform.css";
const SearchForm = () => {
  return (
    <div className='hero'>
    <div className="search-form">
      
      <div className="form-fields">
        <div className="dropdown">
          <label>Select Year</label>
          <select>
            <option value="">Year</option>
            <option value="2018">2018</option>
            <option value="2017">2017</option>
            <option value="2016">2016</option>
          </select>
        </div>

        <div className="dropdown">
          <label>Select Make</label>
          <select>
            <option value=""> Make</option>
            <option value="Toyota">Toyota</option>
            <option value="Honda">Honda</option>
            <option value="Ford">Ford</option>
          </select>
        </div>

        <div className="dropdown">
          <label>Select Model</label>
          <select>
            <option value=""> Model</option>
            <option value="Corolla">Corolla</option>
            <option value="Civic">Civic</option>
            <option value="Mustang">Mustang</option>
          </select>
        </div>

        <div className="dropdown">
          <label>Select Condition</label>
          <select>
            <option value=""> Condition</option>
            <option value="New">New</option>
            <option value="Used">Used</option>
          </select>
        </div>

        <div className="dropdown">
          <label>Select Price</label>
          <select>
            <option value="">Price</option>
            <option value="Below $20,000">Below $20,000</option>
            <option value="$20,000 - $30,000">$20,000 - $30,000</option>
            <option value="Above $30,000">Above $30,000</option>
          </select>
        </div>
        <div className="dropdown">
          <label>Select Year</label>
          <select>
            <option value=""> Year</option>
            <option value="2018">2018</option>
            <option value="2017">2017</option>
            <option value="2016">2016</option>
          </select>
        </div>
      </div>
      <button className="search-button">Search</button>
    </div>
    </div>
  );
};

export default SearchForm;
