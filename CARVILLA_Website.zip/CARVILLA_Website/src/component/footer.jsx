import React from "react";
import "./Footer.css"; 

const Footer = () => {
  return (
    <footer className="footer-container">
      <div className="footer-content">
        <div className="footer-section">
          <h3>CARVILLA</h3>
          <p>
            Ased do eiusmod tempor incidid ut labore et dolore magnaian aliqua.
            Ut enim ad minim veniam.
          </p>
          <p>info@themesine.com</p>
          <p>+1 (885) 2563154554</p>
        </div>
        <div className="footer-section">
          <h4>ABOUT DEVLOON</h4>
          <ul>
            <li>About Us</li>
            <li>Career</li>
            <li>Terms of Service</li>
            <li>Privacy Policy</li>
          </ul>
        </div>
        <div className="footer-section">
          <h4>TOP BRANDS</h4>
          <ul>
            <li>BMW</li>
            <li>Lamborghini</li>
            <li>Camaro</li>
            <li>Audi</li>
            <li>Infiniti</li>
            <li>Nissan</li>
            <li>Ferrari</li>
            
          </ul>
          
        </div>
        <div className="footer-section">
          <h4>NEWS LETTER</h4>
          <p>Subscribe to get latest news updates and information</p>
          <div className="newsletter-input">
            <input type="email" placeholder="Add Email" />
            <button type="button">→</button>
          </div>
        </div>
      </div>
      <div className="footer-bottom">
        <p>© Copyright. Designed And Developed By Themesine.</p>
      </div>
    </footer>
  );
};

export default Footer;
