import React from "react";
import "./CarList.css";

const cars = [
  {
    id: 1,
    image: "car.jpg",
   // model: "Infiniti Z5",
    //price: "$36,850",
    specs: "Model: 2017  3100 mi  240 HP  Automatic",
  },
  {
    id: 2,
    image: "car2.png",
   // model: "Porsche 718 Cayman",
   // price: "$49,500",
    specs: "Model: 2017 | 3100 mi | 240 HP | Automatic",
  },
  {
    id: 3,
    image: "car5.jpg",
   // model: "BMW 8-Series Coupe",
    //price: "$56,000",
    specs: "Model: 2017  3100 mi  240 HP  Automatic",
  },
  {
    id: 4,
    image: "car4.jpg",
   // model: "BMW Xseries-6",
   // price: "$75,800",
    specs: "Model: 2017  3100 Mi  240 HP  Automatic",
  },
];

const CarCards = () => {
  return (
    <div className="car-cards-container">
      {cars.map((car) => (
        <div className="car-card" key={car.id}>
          <img src={car.image} alt={car.model} className="car-image" />
          <h4>{car.model}</h4>
          <p>{car.price}</p>
         <h6></h6>
          <p>{car.specs}</p>
        </div>
      ))}
    </div>
  );
};

export default CarCards;
