import React from "react";
import './Services.css';

const Services = () => {
  return (
    <div>
     
      <section className="services">
       
        <div className="services-container">
          
          <div className="service-card">
            <div className="icon">
              <img src="transport.png"></img>
            </div>
            <h3>Largest Dealership of Car</h3>
            <p>
              Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit
              aut den fugit sed quia.
            </p>
            <div className="d"></div>
          </div>

          
          <div className="service-card">
            <div className="icon">
            <img src="car.png"></img>
            </div>
            <h3>Unlimited Repair Warranty</h3>
            <p>
              Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit
              aut den fugit sed quia.
            </p>
            <div className="d"></div>
          </div>

          
          <div className="service-card">
            <div className="icon">
            <img src="checklist.png"></img>
            </div>
            <h3>Insurance Support</h3>
            <p>
              Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit
              aut den fugit sed quia.
            </p>
            <div className="d"></div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;
