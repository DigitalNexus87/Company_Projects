import React from "react";
import "./ClientTestimonials.css"; // Assuming the CSS file is named ClientTestimonials.css

const testimonials = [
  {
    id: 1,
    name: "Romi Rain",
    location: "London",
    image: "manan.jpg", // Replace with actual image URL
    feedback:
      "Sed ut pers unde omnis iste natus error sit voluptatem accusantium dolor laudan rem aperiam, eaque ipsa quae ab illo inventore verit.",
  },
  {
    id: 2,
    name: "John Doe",
    location: "Washington",
    image: "manan.jpg", // Replace with actual image URL
    feedback:
      "Sed ut pers unde omnis iste natus error sit voluptatem accusantium dolor laudan rem aperiam, eaque ipsa quae ab illo inventore verit.",
    highlighted: true, // Highlight this testimonial
  },
  {
    id: 3,
    name: "Tomas Lili",
    location: "New York",
    image: "manan.jpg", // Replace with actual image URL
    feedback:
      "Sed ut pers unde omnis iste natus error sit voluptatem accusantium dolor laudan rem aperiam, eaque ipsa quae ab illo inventore verit.",
  },
];

const ClientTestimonials = () => {
  return (
    <div className="testimonials-container">
      <h2>What Our Clients Say</h2>
      <div className="testimonials">
        {testimonials.map((testimonial) => (
          <div
            className={`testimonial-card ${
              testimonial.highlighted ? "highlighted" : ""
            }`}
            key={testimonial.id}
          >
            <img
              src={testimonial.image}
              alt={testimonial.name}
              className="testimonial-image"
            />
            <p className="testimonial-feedback">{testimonial.feedback}</p>
            <p className="testimonial-name">
              {testimonial.name} <br />
              <span className="testimonial-location">
                {testimonial.location}
              </span>
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ClientTestimonials;
