import React from "react";
import "./carlist1.css"; // Assuming the CSS file is named CarList.css

const cars = [
  {
    id: 1,
    name: "Infiniti Z5",
    price: "$36,850",
    description:
      "Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non.",
  },
  {
    id: 2,
    name: "Porsche 718 Cayman",
    price: "$49,500",
    description:
      "Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non.",
  },
  {
    id: 3,
    name: "BMW 8-Series Coupe",
    price: "$56,000",
    description:
      "Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non.",
  },
  {
    id: 4,
    name: "BMW Xseries-6",
    price: "$75,800",
    description:
      "Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non.",
  },
];

const CarList1 = () => {
  return (
      <div className="car-list-container">
         <div >
            <h4>BMW Xseries-6</h4>
            <h5>$75,800</h5>
            <p>Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non.</p>
          </div>
          <div>
            <h4>BMW Xseries-6</h4>
            <h5>$75,800</h5>
            <p>Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non.</p>
          </div>
          <div>
            <h4>BMW Xseries-6</h4>
            <h5>$75,800</h5>
            <p>Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non.</p>
          </div>
          <div>
            <h4>BMW Xseries-6</h4>
            <h5>$75,800</h5>
            <p>Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non.</p>
          </div>
          </div>
    
  );
};

export default CarList1;
