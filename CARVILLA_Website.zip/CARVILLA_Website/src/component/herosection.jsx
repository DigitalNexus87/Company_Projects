import React from "react";
import "./HeroSection.css"; 

const HeroSection = () => {
  return (
    <div className="hero-section">
      
      <header className="navbar">
        <div className="logo">CARVILLA</div>
        <nav>
          <ul>
            <li><a href="#" className="active">Home</a></li>
            <li><a href="#">Service</a></li>
            <li><a href="#">Featured Cars</a></li>
            <li><a href="#">New Cars</a></li>
            <li><a href="#">Brands</a></li>
            <li><a href="#">Contact</a></li>
          </ul>
        </nav>
      </header>

      <div className="hero-content">
        <h1>GET YOUR DESIRED CAR IN REASONABLE PRICE</h1>
        <p>
        Explore a wide range of premium and budget-friendly cars to suit your style and needs.<br></br> Drive your dream car today at unbeatable prices!
        </p>
        <button className="contact-button">Contact Us</button>
      </div>
    </div>
  );
};

export default HeroSection;
